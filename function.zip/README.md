# Backend_Python_Lambda_ML_Bitcoin
Create Machine Learning to predict a Bitcoin trend.
